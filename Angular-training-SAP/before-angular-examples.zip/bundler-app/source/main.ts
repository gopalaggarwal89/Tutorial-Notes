import { divide } from './utility';
import { invoke, onSuccess, onFailure } from './invoker';

invoke(divide, onSuccess, onFailure, 12, 3);
