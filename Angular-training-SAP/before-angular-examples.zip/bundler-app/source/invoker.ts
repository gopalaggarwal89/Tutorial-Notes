export const onSuccess = (data: any) => console.log(data);
export const onFailure = (err: any) => console.log(err);

export function invoke(
    operation: (a: number, b: number) => number,
    fnSucces: (success: any) => void,
    fnFailure: (fail: any) => void,
    ...args: number[]) {

    const result = operation(args[0], args[1]);

    if (result === Infinity)
        fnFailure("couldn't divide a number by zero");
    else
        fnSucces(result);
}