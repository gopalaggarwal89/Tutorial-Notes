
export const add = (x: number, y: number) => (x + y);
export const subtract = (x: number, y: number) => (x - y);
export const divide = (x: number, y: number) => (x / y);

