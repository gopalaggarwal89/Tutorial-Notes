const path = require('path');
module.exports = {
    entry: './source/main.ts',
    output: {
        filename: './dist/bundle.js'
    },
    module: {
        rules: [{
            exclude: [
                path.resolve(__dirname, 'node_modules'),
                path.resolve(__dirname, 'bower_components')
            ],
            loader: 'ts-loader'
        }]
    },
    resolve: {
        extensions: ['.ts', '.json', '.css', '.js']
    },
    devtool: 'source-map',
    devServer: {
        contentBase: path.join(__dirname, './'),
        compress: true,
        port: 8089
    }
};