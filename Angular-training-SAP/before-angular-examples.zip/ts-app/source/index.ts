import { DeveloperType } from './developer';
const anil = new DeveloperType('anil', 1, 100, 200, 300, 400);
anil.test(10);