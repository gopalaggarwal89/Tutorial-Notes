//var empModule = require('./employee');
import { EmployeeType } from './employee';
export class DeveloperType extends EmployeeType {
    constructor(name: string, id: number, basic: number, da: number, hra: number, private incentivePay: number, project: string = null) {
        super(name, id, basic, da, hra, project);
    }
    public calculateSalary(): number {
        return super.calculateSalary() + this.incentivePay;
    }
    public test(first: number = 0, second: number = 0) {
        console.log(first);
        console.log(second);
    }
}