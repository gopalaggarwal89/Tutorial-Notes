class EmployeeType {
    constructor(private name: string, private id: number, private basicPay: number, private daPay: number, private hraPay: number, private projectName: string = null) {

    }
    getName(): string {
        return this.name;
    }
    setName(value: string): void {
        this.name = value;
    }
    getProject(): string {
        return this.projectName;
    }
    public calculateSalary(): number {
        return this.basicPay + this.daPay + this.hraPay;
    }
}

//CommonJS format
// module.exports = {
//     //EmployeeType: EmployeeType
//     EmployeeType
// }
const data = [1, 2, 3];
//ES6 module format
export { EmployeeType, data };