const arr = [1, 2, 3];

function printValues() {
    console.log(arr[0])
}
const x = 10;
module.exports = {
    ArrayData: arr,
    printFn: printValues
}