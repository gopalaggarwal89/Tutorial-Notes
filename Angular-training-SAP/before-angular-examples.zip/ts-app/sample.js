var testModule = require('./test');

console.log(testModule.ArrayData);