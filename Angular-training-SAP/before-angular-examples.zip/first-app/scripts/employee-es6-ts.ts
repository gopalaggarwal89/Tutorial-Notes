class EmployeeType {
    constructor(private name: string, private id: number, private basicPay: number, private daPay: number, private hraPay: number, private projectName: string = null) {

    }
    getName(): string {
        return this.name;
    }
    setName(value: string): void {
        this.name = value;
    }
    getProject(): string {
        return this.projectName;
    }
    public calculateSalary(): number {
        return this.basicPay + this.daPay + this.hraPay;
    }
}

class DeveloperType extends EmployeeType {
    constructor(name: string, id: number, basic: number, da: number, hra: number, private incentivePay: number, project: string = null) {
        super(name, id, basic, da, hra, project);
    }
    public calculateSalary(): number {
        return super.calculateSalary() + this.incentivePay;
    }
    public test(first: number = 0, second: number = 0) {
        console.log(first);
        console.log(second);
    }
}

const anil = new DeveloperType('anil', 1, 100, 200, 300, 400);
anil.test(10);