function employee(name, id, basic, da, hra) {
    this.name = name;
    this.id = id;
    this.basicPay = basic;
    this.daPay = da;
    this.hraPay = hra;
}

employee.prototype.calculateSalary = function () {
    return this.basicPay + this.daPay + this.hraPay;
}

function developer(name, id, basic, da, hra, incentive) {
    employee.call(this, name, id, basic, da, hra);
    this.incentivePay = incentive;
}
//in case developer is derived
developer.prototype.calculateSalary = function () {
    let partial = employee.prototype.calculateSalary.apply(this);
    return partial + this.incentivePay;
}

function hr(name, id, basic, da, hra, gratuity) {
    employee.call(this, name, id, basic, da, hra);
    this.gratuityPay = gratuity;
}
//in case hr is derived
hr.prototype.calculateSalary = function () {
    let partialSalary = employee.prototype.calculateSalary.apply(this);
    return partialSalary + this.gratuityPay;
}

let anil =
    new developer('anil', 1, 100, 100, 100, 100);
console.log(anil.calculateSalary());

let sunil = new hr('sunil', 2, 200, 200, 200, 200);
console.log(sunil.calculateSalary());