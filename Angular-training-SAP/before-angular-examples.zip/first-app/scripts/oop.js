//object literal syntax
var anil = {
    firtName: 'anil',
    lastName: 'gupta',
    fullName: function () {
        return this.firtName + ' ' + this.lastName;
    }
};
console.log('printing anil prototype');
console.log(anil.__proto__);

//function constructor

function person(fname, lname) {
    this.firstName = fname;
    this.lastName = lname;
    this.test = function () {
        return "testing";
    }
}
//person.prototype.location = 'Bangalore';
//console.log(person.prototype);

person.prototype.print = function () {
    return this.firstName + ' ' + this.lastName;
}
console.log(person.prototype);
// let sunil = new person('sunil', 'mishra');
// console.log(sunil.fullName());
// console.log('printing snunil prototype');
// console.log(sunil.__proto__);
function trainer(fname, lname, subject) {
    person.call(this, fname, lname);
    this.subject = subject;
    this.print = function () {
        //console.log(person.test.apply(this));
        // let partial = person.prototype.print.apply(this);
        let partial = this.__proto__.print.apply(this);
        return partial + ' ' + this.subject;
    }
}
Object.setPrototypeOf(trainer.prototype, person.prototype);
//person.prototype.location = 'bangalore';
let sunil = new trainer('sunil', 'mishra', 'angular');
console.log(sunil.print());
let res = sunil.test();
console.log(res);
//console.log(sunil.location);
console.log(sunil.__proto__);