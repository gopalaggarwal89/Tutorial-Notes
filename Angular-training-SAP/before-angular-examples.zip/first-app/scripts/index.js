//1. let keyword: ES6
//creates a scoped variable
let x = 10;
for (let i = 0; i < 2; i++) {
    let x = 20;
    console.log(x);
}
console.log(x);

//2. const: ES6
const y = 30;
//y = 40;
console.log(y)
const arr = [1, 2, 3];
//arr = [];<--not legitimate
arr.push(4);

//spread operator: ES6 (...)
function split(s, ...separators) {

    
}

let sentence = 'My name is joy, i work for ariba';
//let sep1 = [' ', ','];
split(sentence, ' ', ',');
let sentence1 = 'My name is joy, i work for ariba. I am from Bangalore';
let sep2 = [' ', ',', '.'];
split(sentence, ' ', ',', '.');