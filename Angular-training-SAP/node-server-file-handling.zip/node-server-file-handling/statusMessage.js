class Status {
    constructor(message) {
        this.message = message;
    }
}
module.exports.Status = Status;